﻿public class Server : RZKomponente
{
    // Nicht veränderbare
    private int _aktuelleTemperatur;
    private int _maxTemperatur = 90;

    // Public Getter: Temperatur ablesbar, aber nicht setzbar
    public int Temperatur => _aktuelleTemperatur;

    // Konstruktor
    public Server(int id, string modell, string bezeichnung) : base(id, modell, bezeichnung)
    {
        _aktuelleTemperatur = 20;
    }

    // Gewünschtes Override wegen angepasster Logik
    public override void Anschalten()
    {
        if (_aktuelleTemperatur > 80)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"WARNUNG: Server {ID} ist zu heiß {_aktuelleTemperatur} °C)! Start verweigert.");
            Console.ResetColor();
            return;
        }

        // Wenn kühl genug, dann ganz normal die BASE Methode verwenden
        base.Anschalten();
    }

    public void Arbeite()
    {
        if(OnlineStatus)
        {
            // Simulation: Server wird heißer
            _aktuelleTemperatur += 5;

            if (_aktuelleTemperatur >= _maxTemperatur)
            {
                LoggeZustand("KRITISCHE ÜBERHITZUNG! NOT-AUS!");
                Ausschalten();
            }
        }
        else
        {
            if(_aktuelleTemperatur > 30)
            {
                _aktuelleTemperatur -= 10;
            }
        }
    }

    
}

