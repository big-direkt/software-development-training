﻿public abstract class RZKomponente
{
    // Readonly Variablen
    public int ID { get; }

    public string Bezeichnung { get; set; }
    public string Modell { get; set; }

    // Kapselung: Außen lesen und Kinder schreiben
    public bool OnlineStatus { get; protected set; }

    // Konstruktor
    public RZKomponente(int id, string modell, string bezeichnung)
    {
        ID = id;
        Modell = modell;
        Bezeichnung = bezeichnung;
        OnlineStatus = false; // Standardwert
    }

    public virtual void Anschalten()
    {
        if (OnlineStatus) return; // Umgehen unnötiger Ausführung

        OnlineStatus = true;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(Modell + " startet...");
        Console.ResetColor();
    }

    virtual public void Ausschalten()
    {
        if (!OnlineStatus) return; // Umgehen unnötiger Ausführung

        OnlineStatus = false;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(Modell + " stoppt");
        Console.ResetColor();
    }

    public void StatusAnzeigen()
    {
        Console.WriteLine($"[Status]: {Modell}, {Bezeichnung}: {OnlineStatus}");
    }

    protected void LoggeZustand(string Nachricht)
    {
        Console.WriteLine($"[LOG INTERN {DateTime.Now:HH:mm:ss}]: {ID} -> {Nachricht}");
    }
}
