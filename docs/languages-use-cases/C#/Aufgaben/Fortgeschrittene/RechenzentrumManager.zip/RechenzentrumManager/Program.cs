﻿class Program
{
    static void Main(string[] args)
    {
        // 1. Setup: Liste erstellen und befüllen
        List<RZKomponente> rz = new List<RZKomponente>();

        // Ein Server
        Server meinServer = new Server(1, "SRV-01", "Dell PowerEdge");
        rz.Add(meinServer);

        // Eine illegale Firewall
        Firewall billigFirewall = new Firewall(1, "FW-01", "China-Import", "12345");
        rz.Add(billigFirewall);

        // Eine echte Firewall
        Firewall guteFirewall = new Firewall(2, "FW-02", "Cisco ASA", "SuperSecure123");
        rz.Add(guteFirewall);

        Console.WriteLine("Drücke Enter um die Simulation zu starten...");
        Console.ReadLine();

        // 2. Der Simulations-Loop
        while (true)
        {
            Console.Clear();
            Console.WriteLine("--- RZ STATUS MONITOR ---");
            Console.WriteLine("{0,-15} | {1,-10} | {2}", "Name", "Status", "Info");
            Console.WriteLine(new string('-', 40));

            // Iteration durch alle Geräte
            foreach (var geraet in rz)
            {
                // Versuche ALLES anzuschalten (Die Klassen entscheiden selbst, ob es geht)
                geraet.Anschalten();

                // Spezielle Logik für Server (Arbeiten simulieren)
                if (geraet is Server s)
                {
                    s.Arbeite(); // Nur Server können arbeiten/überhitzen

                    // Ausgabe für die Tabelle
                    string statusText = s.OnlineStatus ? "ONLINE" : "OFFLINE";
                    Console.WriteLine("{0,-15} | {1,-10} | Temp: {2}°C", s.Modell, statusText, s.Temperatur);
                }
                else
                {
                    // Ausgabe für normale Geräte
                    string statusText = geraet.OnlineStatus ? "ONLINE" : "OFFLINE";
                    Console.WriteLine("{0,-15} | {1,-10} | -", geraet.Modell, statusText);
                }
            }

            Console.WriteLine("\nSimulation läuft... (Strg+C zum Beenden)");
            //Console.ReadLine();
            Thread.Sleep(500); // 0,5 Sekunde warten = 0,5 "Stunde" Simulation
        }
    }
}