﻿public class Firewall : RZKomponente
{
    private string _lizenzKey;
    private bool _istLizenziert;

    // Der Konstruktor erzwingt die Eingabe des Keys
    public Firewall(int id, string modell, string bezeichnung, string key) : base(id, modell, bezeichnung)
    {
        _lizenzKey = key;

        // Prüfung direkt bei Erstellung
        if (_lizenzKey == "SuperSecure123")
        {
            _istLizenziert = true;
        }
        else
        {
            _istLizenziert = false;
            Console.WriteLine($"ACHTUNG: Firewall {ID} hat einen ungültigen Lizenzschlüssel!");
        }
    }

    public override void Anschalten()
    {
        // Das Hindernis: Lizenzblockade
        if (!_istLizenziert)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine($"FEHLER: Firewall {ID} verweigert Start (Keine Lizenz).");
            Console.ResetColor();
            return;
        }

        base.Anschalten();
    }
}

