﻿using System;
using System.Threading;

namespace RechenzentrumManagerAnfaenger
{

    class Program
    {
        static void Main(string[] args)
        {
            Server Server1 = new Server();
            Firewall FirewallUngueltig = new Firewall();
            Firewall FirewallGueltig = new Firewall();

            Server1.Anschalten();
            Server1.Arbeite();
            Server1.SpeicherErweitern(950.27, false);
            Server1.SpeicherErweitern(150.78, true);
            Server1.SoftwareHinzufuegen("JIRA");
            Server1.SoftwareHinzufuegen("Confluence");
            Server1.SoftwareZeigen();

            Console.WriteLine(FirewallUngueltig._lizenzKey);
            FirewallUngueltig.Lizenzieren("1234SuperSecure!");
            FirewallGueltig.Lizenzieren("784fa+r15hcj5");
            FirewallGueltig.Anschalten();
            FirewallUngueltig.Anschalten();
        }
    }
}