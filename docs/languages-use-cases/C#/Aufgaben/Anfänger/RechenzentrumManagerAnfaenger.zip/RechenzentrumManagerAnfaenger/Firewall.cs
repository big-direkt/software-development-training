﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RechenzentrumManagerAnfaenger
{
    public class Firewall : RZKomponente
    {
        public string _lizenzKey { get; set; }
        public List<string> _ungueltigeLizenzKey { get; set; }
        public bool _istLizenziert { get; set; }

        public Firewall(string lizenzKey = "FireW4llKey")
        {
            _lizenzKey = lizenzKey;
            _ungueltigeLizenzKey = ["SuperSecure1324!", "FireWallKey", "TestLizenzKey", "1234SuperSecure!"];
            _istLizenziert = false;
        }

        new public void Anschalten()
        {
            Thread.Sleep(500);
            if (!_istLizenziert)
            {
                Console.WriteLine("Lizenzfehler! Start verweigert.");
            }
            else
            {
                OnlineStatus = true;
            }
        }

        public void Lizenzieren(string LizenzKey)
        {
            if (_ungueltigeLizenzKey.Contains(LizenzKey))
            {
                Console.WriteLine("Die Lizenz ist ungültig. Der Vorgang wird abgebrochen!");
            }
            else
            {
                Console.WriteLine("Die Lizenz ist gültig. Der Vorgang wurde erfolgreich abgeschlossen!");
                _istLizenziert = true;
            }
        }
    }

}
