﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RechenzentrumManagerAnfaenger
{

    public class Server : RZKomponente
    {
        public int _aktuelleTemperatur { get; set; }
        public int _maxTemperatur { get; set; }
        public double _Speichergroesse { get; set; }
        public double _maxSpeichergroesse { get; set; }
        public List<string> _installierteSoftware { get; set; }
        public int Temperatur { get; set; }

        public Server(int aktuelleTemperatur = 20, int maxTemperatur = 90, double Speichergroesse = 100, double maxSpeichergroesse = 100000)
        {
            _aktuelleTemperatur = _aktuelleTemperatur;
            _maxTemperatur = maxTemperatur;
            _Speichergroesse = Speichergroesse;
            _maxSpeichergroesse = maxSpeichergroesse;
            _installierteSoftware = new List<string>();
        }

        public void Arbeite()
        {
            if (OnlineStatus)
            {
                _aktuelleTemperatur += 5;
                if (_aktuelleTemperatur > _maxTemperatur)
                {
                    Ausschalten();
                    LoggeZustand("NOT-AUS WEGEN ÜBERHITZUNG");
                }
            }
            else
            {
                if (_aktuelleTemperatur > 20)
                {
                    _aktuelleTemperatur -= 10;
                }
            }
        }

        new public void Anschalten()
        {
            if (_aktuelleTemperatur > _maxTemperatur)
            {
                Console.WriteLine("Zu heiß zum Starten!");
            }
            else
            {
                OnlineStatus = true;
            }
        }

        public void SpeicherErweitern(double Groesse, bool Art)
        {
            // false -> Reduzieren
            // true -> Erweitern
            if (Art == false)
            {
                if (_Speichergroesse - Groesse >= 100)
                {
                    _Speichergroesse -= Groesse;
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (_Speichergroesse + Groesse < 100000)
                {
                    _Speichergroesse += Groesse;
                }
                else
                {
                    return;
                }
            }

            if ((_Speichergroesse / _maxSpeichergroesse) * 100 > 80)
            {
                double _prozentsatz = (_Speichergroesse / _maxSpeichergroesse) * 100;
                double _restSpeichergroesse = _maxSpeichergroesse - _Speichergroesse;
                Console.WriteLine($"Die derzeitige Speichergröße von {_prozentsatz}% überschreitet die geplanten 80%. Damit bleiben noch {_restSpeichergroesse} MB übrig.");
            }
        }


        public void SoftwareHinzufuegen(string Software)
        {
            _installierteSoftware.Add(Software);
        }

        public void SoftwareZeigen()
        {
            Console.WriteLine("Liste aller installierten Software:");
            foreach (string Software in _installierteSoftware)
            {
                Console.WriteLine(" - " + Software);
            }
        }


    }
}