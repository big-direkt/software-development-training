﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RechenzentrumManagerAnfaenger
{
    public class RZKomponente
    {
        public string ID { get; set; }
        public string Bezeichnung { get; set; }
        public bool OnlineStatus { get; set; }
        public string Modell { get; set; }


        public void Anschalten()
        {
            OnlineStatus = true;
        }

        public void Ausschalten()
        {
            OnlineStatus = false;
        }

        public void StatusAnzeigen()
        {
            Console.WriteLine($"{Modell} {Bezeichnung} {OnlineStatus}");
        }

        public void LoggeZustand(string Nachricht)
        {
            Console.WriteLine($"[INTERN LOG]: {DateTime.Now.ToString()} {Nachricht}");
        }
    }

}
